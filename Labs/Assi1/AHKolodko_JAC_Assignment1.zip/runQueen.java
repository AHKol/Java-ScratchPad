/**
Course: JAC444
Kolodko
Adam
ahkolodko 027 980 127
SAB

This assignment represents my own work in accordance   with Seneca Academic Policy

Date: Oct/12/2017

Constructor Eightqueens to run and display
Adam Koloko
*/
class runQueen{
	public static void main(String[] args){
		@SuppressWarnings("unused")
		//construct and display EightQueens(GridSize)
		EightQueens run = new EightQueens(8);
	}
}