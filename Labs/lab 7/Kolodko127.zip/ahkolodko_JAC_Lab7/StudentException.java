package ws7;

@SuppressWarnings("serial")
public class StudentException extends Exception {
	public StudentException(){
		super();
	}
	
	public StudentException(String message) {
		super(message);
	}
}
